// DoH (RFC 8484) 转发核心逻辑，Workers 与 Pages Functions 共用。

// 内置上游预设，可通过路径选择：/dns-query/google
const PRESETS = {
  cloudflare: "https://cloudflare-dns.com/dns-query",
  google: "https://dns.google/dns-query",
  quad9: "https://dns.quad9.net/dns-query",
  adguard: "https://dns.adguard-dns.com/dns-query",
  opendns: "https://doh.opendns.com/dns-query",
  alidns: "https://dns.alidns.com/dns-query",
  dnspod: "https://doh.pub/dns-query",
};

const DEFAULT_UPSTREAM = "cloudflare";
const TIMEOUT_MS = 5000;

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, POST, OPTIONS",
  "access-control-allow-headers": "content-type, accept",
  "access-control-max-age": "86400",
};

function text(body, status = 200) {
  return new Response(body, {
    status,
    headers: { "content-type": "text/plain; charset=utf-8", ...CORS },
  });
}

// 环境变量 EXTRA_UPSTREAMS 格式：name1=https://a/dns-query,name2=https://b/dns-query
function buildUpstreams(env) {
  const map = { ...PRESETS };
  for (const pair of (env.EXTRA_UPSTREAMS || "").split(",")) {
    const i = pair.indexOf("=");
    if (i > 0) {
      const name = pair.slice(0, i).trim().toLowerCase();
      const url = pair.slice(i + 1).trim();
      if (name && url.startsWith("https://")) map[name] = url;
    }
  }
  return map;
}

function resolveUpstream(name, env) {
  const map = buildUpstreams(env);
  const def = (env.UPSTREAM || DEFAULT_UPSTREAM).trim();
  // UPSTREAM 既可以是预设名，也可以直接是完整 https URL
  const defUrl = def.startsWith("https://") ? def : map[def.toLowerCase()];
  if (!name) return defUrl || PRESETS[DEFAULT_UPSTREAM];
  return map[name.toLowerCase()] || null;
}

function parseTokens(raw) {
  return (raw || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

// 常量时间比较，避免通过响应时间猜测令牌
function safeEqual(a, b) {
  const enc = new TextEncoder();
  const x = enc.encode(a);
  const y = enc.encode(b);
  let diff = x.length ^ y.length;
  const n = Math.max(x.length, y.length);
  for (let i = 0; i < n; i++) diff |= (x[i] || 0) ^ (y[i] || 0);
  return diff === 0;
}

export async function handleDoh(request, env = {}) {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }

  const url = new URL(request.url);
  let segs = url.pathname.split("/").filter(Boolean);

  // 可选访问令牌：设置 TOKEN 后，路径必须为 /<TOKEN>/dns-query[/上游名]
  // TOKEN 支持多个，用逗号分隔（便于给不同设备/用户分配、单独吊销）
  const tokens = parseTokens(env.TOKEN);
  if (tokens.length) {
    if (!segs[0] || !tokens.some((t) => safeEqual(segs[0], t))) {
      return text("Not Found", 404); // 不暴露服务存在
    }
    segs = segs.slice(1);
  }

  if (segs[0] !== "dns-query") {
    if (segs.length === 0) {
      return text(
        "DoH forwarder is running.\nEndpoint: /dns-query[/upstream]\nUpstreams: " +
          Object.keys(buildUpstreams(env)).join(", ") +
          "\n"
      );
    }
    return text("Not Found", 404);
  }

  const upstream = resolveUpstream(segs[1], env);
  if (!upstream) return text("Unknown upstream", 400);

  let init;
  if (request.method === "GET") {
    init = { method: "GET", headers: { accept: request.headers.get("accept") || "application/dns-message" } };
  } else if (request.method === "POST") {
    const ct = request.headers.get("content-type") || "";
    if (!ct.includes("application/dns-message")) return text("Unsupported Media Type", 415);
    init = {
      method: "POST",
      headers: { "content-type": "application/dns-message", accept: "application/dns-message" },
      body: await request.arrayBuffer(),
    };
  } else {
    return text("Method Not Allowed", 405);
  }

  let resp;
  try {
    // GET 时原样转发查询参数（?dns=... 或 JSON 格式的 ?name=&type=）
    const target = request.method === "GET" ? upstream + url.search : upstream;
    resp = await fetch(target, { ...init, signal: AbortSignal.timeout(TIMEOUT_MS) });
  } catch (e) {
    return text("Upstream error: " + (e && e.message ? e.message : "unknown"), 502);
  }

  const headers = new Headers(CORS);
  for (const h of ["content-type", "cache-control"]) {
    const v = resp.headers.get(h);
    if (v) headers.set(h, v);
  }
  return new Response(resp.body, { status: resp.status, headers });
}

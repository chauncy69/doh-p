import { handleDoh } from "./doh.js";

export default {
  async fetch(request, env) {
    return handleDoh(request, env);
  },
};

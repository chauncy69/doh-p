// Cloudflare Pages Functions：捕获所有路径并交给共用的 DoH 逻辑处理
import { handleDoh } from "../src/doh.js";

export async function onRequest(context) {
  return handleDoh(context.request, context.env);
}
